import React from "react";


const Login = () => {
    return(
        <nav>
            <h3>Login</h3>
        </nav>
    )
}
export default Login