import React from "react";
const DangKy = () => {
    return(
        <nav>
            <h3>Register</h3>
        </nav>
    )
}
export default DangKy