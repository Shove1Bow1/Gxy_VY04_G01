import React from "react";
const DangKy = () => {
    return(
        <nav style={{width:100+"%"}}>
            <h3>Login</h3>
        </nav>
    )
}
export default DangKy